import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';

const MPU6050Display = () => {
  const [sensorData, setSensorData] = useState({
    accelerometer: { x: 0, y: 0, z: 0 },
    gyroscope: { x: 0, y: 0, z: 0 }
  });

  useEffect(() => {
    const fetchData = () => {
      fetch('http://localhost:5000/data')
        .then(response => response.json())
        .then(data => setSensorData(data))
        .catch(error => console.error('Error:', error));
    };

    // 每3秒更新一次數據
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">MPU6050 即時數據</h1>
      
      <Card className="mb-4">
        <CardHeader>
          <CardTitle>加速度計數據 (g)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="font-semibold">X 軸</div>
              <div className="text-xl">{sensorData.accelerometer.x}</div>
            </div>
            <div className="text-center">
              <div className="font-semibold">Y 軸</div>
              <div className="text-xl">{sensorData.accelerometer.y}</div>
            </div>
            <div className="text-center">
              <div className="font-semibold">Z 軸</div>
              <div className="text-xl">{sensorData.accelerometer.z}</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>陀螺儀數據 (°/s)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="font-semibold">X 軸</div>
              <div className="text-xl">{sensorData.gyroscope.x}</div>
            </div>
            <div className="text-center">
              <div className="font-semibold">Y 軸</div>
              <div className="text-xl">{sensorData.gyroscope.y}</div>
            </div>
            <div className="text-center">
              <div className="font-semibold">Z 軸</div>
              <div className="text-xl">{sensorData.gyroscope.z}</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MPU6050Display;
