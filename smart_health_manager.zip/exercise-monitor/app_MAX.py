from flask import Flask, jsonify, send_file, Response
from flask_cors import CORS
import json
from heartrate_monitor import HeartRateMonitor
import threading
import time

app = Flask(__name__)
CORS(app)

# 全局變量來存儲感測器實例和狀態
sensor = None
is_monitoring = False
current_data = {"bpm": 0, "spo2": 0}

def update_sensor_data():
    global sensor, is_monitoring, current_data
    while is_monitoring:
        if sensor:
            current_data["bpm"] = sensor.filtered_bpm
            current_data["spo2"] = sensor.filtered_spo2
        time.sleep(0.1)  # 每0.1秒更新一次數據

@app.route('/start', methods=['POST'])
def start_monitoring():
    global sensor, is_monitoring
    if not is_monitoring:
        sensor = HeartRateMonitor(print_raw=False, print_result=True)
        sensor.start_sensor()
        is_monitoring = True
        # 啟動數據更新線程
        threading.Thread(target=update_sensor_data).start()
        return jsonify({"status": "success", "message": "Monitoring started"})
    return jsonify({"status": "error", "message": "Already monitoring"})

@app.route('/stop', methods=['POST'])
def stop_monitoring():
    global sensor, is_monitoring
    if is_monitoring:
        is_monitoring = False
        if sensor:
            sensor.stop_sensor()
            sensor = None
        return jsonify({"status": "success", "message": "Monitoring stopped"})
    return jsonify({"status": "error", "message": "Not monitoring"})

@app.route('/data')
def get_data():
    global current_data
    return jsonify(current_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
