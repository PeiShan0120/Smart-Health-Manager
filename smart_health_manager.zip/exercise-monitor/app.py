from flask import Flask, jsonify, request, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
import threading
import time
import smbus
from heartrate_monitor import HeartRateMonitor

# mysql 
import pymysql

import datetime
import mysql.connector
from mysql.connector import Error

# line notify
import requests

# led
from gpiozero import LEDBoard
from time import sleep
from signal import pause

app = Flask(__name__)
app.secret_key = 'my_secret_key'
CORS(app)

# led light
ledR = LEDBoard(13)
ledG = LEDBoard(19)
ledB = LEDBoard(26)

# 全局變量
user_id = None
user_name = None
timestamp = None
start_time = None
sensor = None
is_monitoring = False
is_normal = True
monitor_thread = None
current_data = {
    "bpm": 0,
    "spo2": 0,
    "accelX": 0,
    "accelY": 0,
    "accelZ": 0,
    "time" : 0,
    "error": None
}

min_bpm = None
max_bpm = None
send_time = None

LINE_NOTIFY_TOKEN = 'oY4OTqEEbw3E2VmesyAffgmp2zz7n9BRAewxDwK8A5O'

def send_line_notify(message, line_id, name):
    global send_time
    if send_time != None and (datetime.datetime.now().timestamp()) - send_time < 30:
        return
    send_time = datetime.datetime.now().timestamp()

    url = 'https://notify-api.line.me/api/notify'
    headers = {
        'Authorization': f'Bearer {LINE_NOTIFY_TOKEN}',
    }
    payload = {
        'message': f'{name} {message}',  # 傳送訊息給指定的 Line ID
    }
    
    response = requests.post(url, headers=headers, data=payload)
    if response.status_code == 200:
        print(f"警報訊息已發送給 {name}")
    else:
        print("發送警報訊息失敗，狀態碼:", response.status_code)

def reset_state():
    global sensor, is_monitoring, monitor_thread, current_data
    is_monitoring = False
    if sensor:
        try:
            sensor.stop_sensor()
        except:
            pass
        sensor = None
    if monitor_thread and monitor_thread.is_alive():
        monitor_thread.join(timeout=1.0)
    current_data = {
        "bpm": 0,
        "spo2": 0,
        "accelX": 0,
        "accelY": 0,
        "accelZ": 0,
        "time" : 0,
        "error": None
    }

def init_mpu6050():
    try:
        bus = smbus.SMBus(1)
        device_address = 0x68
        
        # 初始化 MPU6050
        bus.write_byte_data(device_address, 0x6B, 0)
        time.sleep(0.1)
        
        return bus, device_address
    except Exception as e:
        print(f"MPU6050 初始化錯誤: {str(e)}")
        return None, None

def read_acceleration(bus, addr):
    try:
        # 讀取加速度數據
        x = read_word_2c(bus, addr, 0x3B) / 16384.0
        y = read_word_2c(bus, addr, 0x3D) / 16384.0
        z = read_word_2c(bus, addr, 0x3F) / 16384.0
        return x, y, z
    except Exception as e:
        print(f"讀取加速度錯誤: {str(e)}")
        return 0, 0, 0

def read_word_2c(bus, addr, reg):
    try:
        high = bus.read_byte_data(addr, reg)
        low = bus.read_byte_data(addr, reg+1)
        val = (high << 8) + low
        if val >= 0x8000:
            return -((65535 - val) + 1)
        else:
            return val
    except Exception as e:
        print(f"讀取數據錯誤: {str(e)}")
        return 0

def update_sensor_data():
    global sensor, is_monitoring, current_data, is_normal, user_name, ledR, ledG, ledB
    
    print("初始化感測器...")
    bus, device_address = init_mpu6050()
    if not bus or not device_address:
        current_data["error"] = "無法初始化 MPU6050"
        return
        
    print("開始監測數據...")
    
    while is_monitoring:
        bpms = []
        spo2s = []
        accelXs = []
        accelYs = []
        accelZs = []
        for i in range(5):
            try:
                # 更新心率和血氧
                if sensor and sensor.filtered_bpm is not None:
                    bpm = sensor.filtered_bpm
                    spo2 = sensor.filtered_spo2
                
                # 更新加速度
                x, y, z = read_acceleration(bus, device_address)
                
                if bpm != 0 and spo2 != 0:
                    bpms.append(bpm)
                    spo2s.append(spo2)
                    accelXs.append(x)
                    accelYs.append(y)
                    accelZs.append(z)
            except Exception as e:
                print(f"更新數據錯誤: {str(e)}")
            time.sleep(1)

        if len(bpms) > 0:
            # 更新平均心率和血氧
            current_data["bpm"] = sum(bpms) / len(bpms)
            current_data["spo2"] = sum(spo2s) / len(spo2s)
            
            # 更新平均加速度
            current_data["accelX"] = sum(accelXs) / len(accelXs)
            current_data["accelY"] = sum(accelYs) / len(accelYs)
            current_data["accelZ"] = sum(accelZs) / len(accelZs)
            
            current_data["time"] = time.time()

            current_data["error"] = None

            if current_data["bpm"] != 0:
                if current_data["bpm"] > max_bpm or current_data["bpm"] < min_bpm:
                    is_normal = False

                    if current_data["bpm"] > max_bpm:
                        send_line_notify('目前心率過高，請留意身體狀況，降低運動量','',user_name)
                        ledG.off()
                        ledB.off()
                        ledR.on()
                        

                    if current_data["bpm"] < min_bpm:
                        send_line_notify('目前心率不達最佳範圍，請增加運動量','',user_name)
                        ledG.off()
                        ledR.off()
                        ledB.on()

                else:
                    ledB.off()
                    ledR.off()
                    ledG.on()
            
            if current_data["spo2"] != 0 and current_data["spo2"] < 85:
                is_normal = False
                send_line_notify(f'目前血氧濃度過低，為避免暈眩，請暫時休息','',user_name)

            # 寫入資料庫
            record_sensor_data()

# Function to create MySQL connection
def get_db_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        port=3306,
        password='pei01201',
        database='exercise_monitor'
    )
    return connection

# db connection
def record_sensor_data():
    try:
        connection = get_db_connection()

        if connection.is_connected():
            print("Successfully connected to the database")

            # Prepare the INSERT statement
            insert_query = """
            INSERT INTO history_detail (user_id, event_id, time, spo2, bpm, accelX, accelY, accelZ)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """

            # Data to insert
            data = (
                user_id,
                timestamp,
                datetime.datetime.fromtimestamp(current_data["time"]),
                float(current_data["spo2"]),
                float(current_data["bpm"]),
                current_data["accelX"],
                current_data["accelY"],
                current_data["accelZ"]
            )

            # Create a cursor object to execute queries
            cursor = connection.cursor()
            
            # Execute the insert query
            cursor.execute(insert_query, data)
            
            # Commit the transaction
            connection.commit()
            print("Data inserted successfully")

    except Error as e:
        print("Error while connecting to MySQL", e)

    finally:
        # Close the cursor and connection
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

def get_average_spo2_by_event(event_id):
    average_spo2 = 0.0
    try:
        connection = get_db_connection()

        if connection.is_connected():
            print("Successfully connected to the database")

            # Prepare the INSERT statement
            sql_query = f"SELECT AVG(spo2) AS average_spo2 FROM history_detail WHERE event_id = {event_id};"

            # Create a cursor object to execute queries
            cursor = connection.cursor()
            
            # Execute the insert query
            cursor.execute(sql_query)

            # Fetch the result
            result = cursor.fetchone()

            average_spo2 = result[0]
            
            # Commit the transaction
            connection.commit()
            print("Data inserted successfully")

    except Error as e:
        print("Error while connecting to MySQL", e)
    finally:
        # Close the cursor and connection
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")
    return average_spo2

def get_average_bpm_by_event(event_id):
    average_bpm = 0.0
    try:
        connection = get_db_connection()

        if connection.is_connected():
            print("Successfully connected to the database")

            # Prepare the INSERT statement
            sql_query = f"SELECT AVG(bpm) AS average_bpm FROM history_detail WHERE event_id = {event_id};"

            # Create a cursor object to execute queries
            cursor = connection.cursor()
            
            # Execute the insert query
            cursor.execute(sql_query)

            # Fetch the result
            result = cursor.fetchone()

            average_bpm = result[0]
            
            # Commit the transaction
            connection.commit()
            print("Data inserted successfully")

    except Error as e:
        print("Error while connecting to MySQL", e)
    finally:
        # Close the cursor and connection
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")
    return average_bpm

def record_history():
    try:
        connection = get_db_connection()

        if connection.is_connected():
            print("Successfully connected to the database")

            # Prepare the INSERT statement
            insert_query = """
            INSERT INTO history_data (user_id, event_id, start_time, end_time, spo2, bpm, health)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            """

            # Data to insert
            data = (
                user_id,
                timestamp,
                start_time,
                datetime.datetime.now(),
                get_average_spo2_by_event(timestamp),
                get_average_bpm_by_event(timestamp),
                is_normal
            )

            # Create a cursor object to execute queries
            cursor = connection.cursor()
            
            # Execute the insert query
            cursor.execute(insert_query, data)
            
            # Commit the transaction
            connection.commit()
            print("Data inserted successfully")

    except Error as e:
        print("Error while connecting to MySQL", e)

    finally:
        # Close the cursor and connection
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

@app.route('/user', methods=['GET'])
def get_user():
    global user_id, user_name, max_bpm, min_bpm
    # Connect to the MySQL database
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM user_data WHERE id=%s", (user_id, ))
    user = cursor.fetchone()

    if user:
        user_id = user[0]  # Assuming user[0] is the user ID
        user_name = user[1]

        # birthdate = datetime.datetime.strptime(user[4], "%a, %d %b %Y %H:%M:%S GMT")
        birthdate = user[4]
        today = datetime.datetime.today()
        age = today.year - birthdate.year
        if (today.month, today.day) < (birthdate.month, birthdate.day):
            age -= 1

        if age < 30:
            min_bpm = 100
            max_bpm = 170
        elif age < 35:
            min_bpm = 95
            max_bpm = 162
        elif age < 40:
            min_bpm = 93
            max_bpm = 157
        elif age < 45:
            min_bpm = 90
            max_bpm = 153
        elif age < 50:
            min_bpm = 88
            max_bpm = 149
        elif age < 55:
            min_bpm = 85
            max_bpm = 145
        elif age < 60:
            min_bpm = 83
            max_bpm = 140
        elif age < 65:
            min_bpm = 80
            max_bpm = 136
        elif age < 70:
            min_bpm = 78
            max_bpm = 132
        else:
            min_bpm = 75
            max_bpm = 128

        return jsonify({'success': True, "name" : user[1], "age" : age})
    else:
        return jsonify({'success': False, 'message': 'Invalid user id'})

@app.route('/start', methods=['POST'])
def start_monitoring():
    global sensor, timestamp, start_time, is_monitoring, is_normal, monitor_thread
    print("收到開始監測請求")
    
    try:
        # 先重置所有狀態
        reset_state()
        
        print("初始化感測器...")
        sensor = HeartRateMonitor(print_raw=False, print_result=True)
        sensor.start_sensor()
        
        print("啟動監測...")
        timestamp = int(datetime.datetime.now().timestamp())
        start_time = datetime.datetime.now()
        is_normal = True
        is_monitoring = True
        
        # 啟動新的數據更新線程
        monitor_thread = threading.Thread(target=update_sensor_data, daemon=True)
        monitor_thread.start()
        
        return jsonify({"status": "success", "message": "監測開始"})
    except Exception as e:
        print(f"啟動錯誤: {str(e)}")
        reset_state()
        return jsonify({"status": "error", "message": f"啟動失敗: {str(e)}"})

# Register Route
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    name = data['name']
    email = data['email']
    password = data['password']
    birthday = data['birthday']
    
    # Server-side validation: Check if any field is empty
    if not name or not email or not password or not birthday:
        return jsonify({"success": False, "message": "All fields are required!"}), 400
    
    # Connect to the MySQL database
    connection = get_db_connection()
    cursor = connection.cursor()

    # Check if email already exists
    cursor.execute("SELECT * FROM user_data WHERE email=%s", (email,))
    existing_user = cursor.fetchone()

    if existing_user:
        cursor.close()
        connection.close()
        return jsonify({"success": False, "message": "Email already in use!"}), 400

    # Insert new user into the database
    cursor.execute("INSERT INTO user_data (name, email, password, birthday) VALUES (%s, %s, %s, %s)",
                   (name, email, password, birthday))
    connection.commit()

    cursor.close()
    connection.close()
    
    return jsonify({"success": True, "message": "Registration successful!"})

# Route for the login page
@app.route('/login', methods=['POST'])
def login():
    global user_id
    data = request.get_json()
    email = data['email']
    password = data['password']
    print(f"email : {email}")
    print(f"password : {password}")

    # Connect to the MySQL database
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("SELECT * FROM user_data WHERE email=%s AND password=%s", (email, password))
    user = cursor.fetchone()

    if user:
        print(f"Login user id : {user[0]}")
        print(user)
        user_id = user[0]  # Assuming user[0] is the user ID
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': 'Invalid username or password'})

@app.route('/stop', methods=['POST'])
def stop_monitoring():
    global ledR, ledG, ledB
    print("收到停止監測請求")
    reset_state()
    record_history()

    ledR.off()
    ledG.off()
    ledB.off()
    return jsonify({"status": "success", "message": "監測已停止"})

@app.route('/data')
def get_data():
    global current_data
    return jsonify(current_data)

@app.route('/history', methods=['GET'])
def get_history_data():
    # Retrieve the parameters from the query string
    event_id = request.args.get('event_id')
    if event_id:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # 查詢 history_data 表格中的所有資料
        cursor.execute("SELECT * FROM history_detail WHERE event_id=%s", (event_id, ))
        rows = cursor.fetchall()

        cursor.close()
        connection.close()
        return jsonify(rows)
    else:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)

        # 查詢 history_data 表格中的所有資料
        cursor.execute("SELECT * FROM history_data WHERE user_id=%s", (user_id, ))
        rows = cursor.fetchall()

        cursor.close()
        connection.close()
        return jsonify(rows)

if __name__ == '__main__':
    print("伺服器啟動...")
    # 啟動時先重置所有狀態
    reset_state()
    app.run(host='0.0.0.0', port=5000, debug=True)
