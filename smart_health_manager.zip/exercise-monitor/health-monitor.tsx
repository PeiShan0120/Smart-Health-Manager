import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

const BreathingGuide = ({ show, onComplete }) => {
  const [countdown, setCountdown] = useState(3);
  
  useEffect(() => {
    if (show && countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    } else if (countdown === 0) {
      onComplete();
    }
  }, [show, countdown]);

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg text-center">
        <h2 className="text-2xl font-bold mb-4">深呼吸準備</h2>
        <p className="text-lg mb-4">請準備進行深呼吸測試</p>
        <p className="text-3xl font-bold">{countdown}</p>
      </div>
    </div>
  );
};

const HealthMonitor = () => {
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [showBreathingGuide, setShowBreathingGuide] = useState(false);
  const [data, setData] = useState({
    bpm: 0,
    spo2: 0,
    breathingRate: 0,
    acceleration: { x: 0, y: 0, z: 0 }
  });
  const [chartData, setChartData] = useState([]);
  const [error, setError] = useState(null);

  const startMonitoring = async () => {
    try {
      setShowBreathingGuide(true);
    } catch (err) {
      setError('無法啟動監測: ' + err.message);
    }
  };

  const handleBreathingGuideComplete = async () => {
    setShowBreathingGuide(false);
    try {
      const response = await fetch('http://localhost:5000/start', {
        method: 'POST'
      });
      const result = await response.json();
      if (result.status === 'success') {
        setIsMonitoring(true);
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError('無法連接到伺服器');
    }
  };

  const stopMonitoring = async () => {
    try {
      const response = await fetch('http://localhost:5000/stop', {
        method: 'POST'
      });
      const result = await response.json();
      if (result.status === 'success') {
        setIsMonitoring(false);
        setError(null);
      } else {
        setError(result.message);
      }
    } catch (err) {
      setError('無法連接到伺服器');
    }
  };

  useEffect(() => {
    let interval;
    if (isMonitoring) {
      interval = setInterval(async () => {
        try {
          const [healthResponse, motionResponse] = await Promise.all([
            fetch('http://localhost:5000/data'),
            fetch('http://localhost:8000/data')
          ]);
          
          const healthData = await healthResponse.json();
          const motionData = await motionResponse.json();
          
          const newData = {
            bpm: healthData.bpm,
            spo2: healthData.spo2,
            breathingRate: motionData.breathingRate,
            acceleration: motionData.accelerometer
          };
          
          setData(newData);
          setChartData(prev => [...prev, {
            time: new Date().toLocaleTimeString(),
            ...newData
          }].slice(-30));
          
        } catch (err) {
          setError('無法取得數據');
          setIsMonitoring(false);
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isMonitoring]);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-6 text-center">
        <h1 className="text-3xl font-bold mb-4">健康監測儀表板</h1>
        <div className="space-x-4">
          <button
            onClick={startMonitoring}
            disabled={isMonitoring}
            className={`px-4 py-2 rounded ${
              isMonitoring ? 'bg-gray-400' : 'bg-green-600'
            } text-white`}
          >
            開始監測
          </button>
          <button
            onClick={stopMonitoring}
            disabled={!isMonitoring}
            className={`px-4 py-2 rounded ${
              !isMonitoring ? 'bg-gray-400' : 'bg-red-600'
            } text-white`}
          >
            停止監測
          </button>
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>錯誤</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-2">心率</h2>
          <p className="text-4xl font-bold text-red-600">
            {Math.round(data.bpm) || '--'} <span className="text-base">BPM</span>
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-2">血氧濃度</h2>
          <p className="text-4xl font-bold text-blue-600">
            {data.spo2 ? data.spo2.toFixed(1) : '--'} <span className="text-base">%</span>
          </p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md">
          <h2 className="text-lg font-semibold mb-2">呼吸頻率</h2>
          <p className="text-4xl font-bold text-green-600">
            {data.breathingRate || '--'} <span className="text-base">次/分</span>
          </p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-lg font-semibold mb-4">即時數據趨勢</h2>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="bpm" stroke="#ef4444" name="心率" />
              <Line yAxisId="right" type="monotone" dataKey="spo2" stroke="#3b82f6" name="血氧" />
              <Line yAxisId="left" type="monotone" dataKey="breathingRate" stroke="#22c55e" name="呼吸" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <BreathingGuide 
        show={showBreathingGuide} 
        onComplete={handleBreathingGuideComplete} 
      />
    </div>
  );
};

export default HealthMonitor;
