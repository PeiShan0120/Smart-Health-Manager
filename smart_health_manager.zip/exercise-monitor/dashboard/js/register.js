document.getElementById("register-form").addEventListener("submit", async function(event) {
    event.preventDefault();
    
    const name = document.getElementById("exampleInputName").value;
    const email = document.getElementById("exampleInputEmail").value;
    const password = document.getElementById("exampleInputPassword").value;
    const confirmPassword = document.getElementById("exampleRepeatPassword").value;
    const birthday = document.getElementById("exampleInputBirth").value;
     
    // Check if any field is empty
    if (!name || !email || !password || !confirmPassword || !birthday) {
        alert("All fields are required!");
        return;
    }

    // Check if the name is allowed
    const regex = /^[a-zA-Z\u4e00-\u9fa5\s]+$/;
    if (!regex.test(name)) {
        alert('Symbol and Number is not allowed.\nAllowed word:["English","Chinese"]');
        return;
    }


    // Check if the domain is in the allowed list
    const allowedDomains = ["gmail.com", "yahoo.com", "icloud.com"];
    const domain = email.split('@')[1];
    if (!allowedDomains.includes(domain)) {
        alert(`${email} is not allowed.\nAllowed email:["gmail.com", "yahoo.com", "icloud.com"]`);
        return;
    }

    // Check if birthday is in future
    const birthdayDate = new Date(birthday);
    const today = new Date();
    if (birthdayDate >= today) {
        alert(`${birthday} doesn't existed.`);
        return;
    }

    // Check if password and confirm password match
    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    const data = { name, email, password, birthday };
    
    try {
        const response = await fetch("http://172.20.10.14:5000/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            alert("Registration successful!");
            window.location.href = "./login.html";  // Redirect to login page
        } else {
            alert("Error: " + result.message);
        }
    } catch (error) {
        console.error("Error:", error);
    }
});
