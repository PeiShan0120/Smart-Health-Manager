function getParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

const event_id = getParameter('event_id');

var user_name;
var user_age;
var min_bpm;
var max_bpm;

const spo2Chart = document.getElementById('spo2Chart');
const bpmChart = document.getElementById('bpmChart');

spo2Chart.style.display = 'none';
bpmChart.style.display = 'none';

function formatDate(date) {
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Get month (1-12), pad with 0
    const day = String(date.getDate()).padStart(2, '0'); // Get day (1-31), pad with 0
    const hours = String(date.getHours()).padStart(2, '0'); // Get hours (0-23), pad with 0
    const minutes = String(date.getMinutes()).padStart(2, '0'); // Get minutes (0-59), pad with 0
    const seconds = String(date.getSeconds()).padStart(2, '0'); // Get seconds (0-59), pad with 0

    return `${month}/${day} ${hours}:${minutes}`;
}

function displayChart(data) {
    spo2Chart.style.display = 'block';
    bpmChart.style.display = 'block';

    const timeLabels = data.map(entry => new Date(entry.time));
    const bpmValues = data.map(entry => entry.bpm);
    const spo2Values = data.map(entry => entry.spo2);

    // Determine the colors based on BPM values
    const ctx = document.getElementById('bpmAreaChart').getContext('2d');

    const bpmPointColor = bpmValues.map(bpm => bpm > max_bpm || bpm < min_bpm ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    const myLineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: "BPM",
                lineTension: 0.3,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                pointRadius: 3,
                pointBackgroundColor: bpmPointColor,
                pointBorderColor: bpmPointColor,
                pointHoverRadius: 3,
                pointHoverBackgroundColor: 'rgba(0, 0, 0, 1)',
                pointHoverBorderColor: 'rgba(0, 0, 0, 1)',
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: bpmValues,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7,
                        callback: function (value, index, values) {
                            return formatDate(value);
                        }
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function (value, index, values) {
                            return value;
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function (tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel;
                    }
                }
            }
        }
    });

    // Determine the colors based on spo2 values
    const spo2Ctx = document.getElementById('spo2AreaChart').getContext('2d');

    const spo2PointColor = spo2Values.map(spo2 => spo2 < 85 ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    const apo2LineChart = new Chart(spo2Ctx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: "SPO2",
                lineTension: 0.3,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                pointRadius: 3,
                pointBackgroundColor: spo2PointColor,
                pointBorderColor: spo2PointColor,
                pointHoverRadius: 3,
                pointHoverBackgroundColor: 'rgba(0, 0, 0, 1)',
                pointHoverBorderColor: 'rgba(0, 0, 0, 1)',
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: spo2Values,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 7,
                        callback: function (value, index, values) {
                            return formatDate(value);
                        }
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function (value, index, values) {
                            return value + '%';
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function (tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel + '%';
                    }
                }
            }
        }
    });
}

fetch('http://172.20.10.14:5000//user')
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if (data.success) {
            user_name = data.name;
            user_age = data.age;
            if (user_age < 30) {
                min_bpm = 100;
                max_bpm = 170;
            } else if (user_age < 35) {
                min_bpm = 95;
                max_bpm = 162;
            } else if (user_age < 40) {
                min_bpm = 93;
                max_bpm = 157;
            } else if (user_age < 45) {
                min_bpm = 90;
                max_bpm = 153;
            } else if (user_age < 50) {
                min_bpm = 88;
                max_bpm = 149;
            } else if (user_age < 55) {
                min_bpm = 85;
                max_bpm = 145;
            } else if (user_age < 60) {
                min_bpm = 83;
                max_bpm = 140;
            } else if (user_age < 65) {
                min_bpm = 80;
                max_bpm = 136;
            } else if (user_age < 70) {
                min_bpm = 78;
                max_bpm = 132;
            } else {
                min_bpm = 75;
                max_bpm = 128;
            }

            document.getElementById('userName').textContent = user_name;
        } else {
            window.location.href = './login.html';
        }
    })
    .catch(error => console.error('Error fetching data:', error));

if (event_id) {
    // Construct the URL with query parameters
    const url = new URL('http://172.20.10.14:5000//history');
    const params = { event_id };
    url.search = new URLSearchParams(params).toString();

    fetch(url)
        .then(response => response.json())
        .then(data => {
            displayChart(data);

            const tableHead = document.querySelector('#history-data-table thead');
            tableHead.innerHTML = '';  // 清空現有的資料
            const trHead = document.createElement('tr');
            trHead.innerHTML = `
                <th>時間</th>
                <th>血氧濃度</th>
                <th>心率</th>
                <th>X軸加速度</th>
                <th>Y軸加速度</th>
                <th>Z軸加速度</th>
            `;
            tableHead.appendChild(trHead);

            const tableBody = document.querySelector('#history-data-table tbody');
            tableBody.innerHTML = '';  // 清空現有的資料

            // 插入資料列
            data.forEach(row => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${row.time}</td>
                    <td>${row.spo2}</td>
                    <td>${row.bpm}</td>
                    <td>${row.accelX}</td>
                    <td>${row.accelY}</td>
                    <td>${row.accelZ}</td>
                `;
                tableBody.appendChild(tr);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
} else {
    fetch('http://172.20.10.14:5000//history')
        .then(response => response.json())
        .then(data => {
            const tableHead = document.querySelector('#history-data-table thead');
            tableHead.innerHTML = '';  // 清空現有的資料
            const trHead = document.createElement('tr');
            trHead.innerHTML = `
                <th>ID</th>
                <th>開始時間</th>
                <th>結束時間</th>
                <th>平均血氧濃度</th>
                <th>平均心率</th>
                <th>健康狀況</th>
            `;
            tableHead.appendChild(trHead);

            const tableBody = document.querySelector('#history-data-table tbody');
            tableBody.innerHTML = '';  // 清空現有的資料

            // 插入資料列
            data.forEach(row => {
                const tr = document.createElement('tr');
                var health;
                if (row.health == 1) {
                    health = "健康";
                } else {
                    health = "異常";
                }
                tr.innerHTML = `
                    <td>${row.event_id}</td>
                    <td>${row.start_time}</td>
                    <td>${row.end_time}</td>
                    <td>${row.spo2}</td>
                    <td>${row.bpm}</td>
                    <td>${health}</td>
                `;
                tableBody.appendChild(tr);

                tr.addEventListener('click', function() {
                    window.location.href = './history.html?event_id=' + row.event_id;
                });
            });
        })
        .catch(error => console.error('Error fetching data:', error));
}