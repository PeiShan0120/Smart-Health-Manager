let isMonitoring = false;
let lastValues = { bpm: 0, spo2: 0, time: 0};

const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const errorMsg = document.getElementById('errorMsg');

var user_name;
var user_age;
var min_bpm;
var max_bpm;

var start_time;

// react chart
var bpmChart;
var spo2Chart;
var times = [];
var bpms = [];
var spo2s = [];

function showError(message) {
    console.error(message);
    errorMsg.textContent = message;
    errorMsg.style.display = 'block';
}

function hideError() {
    errorMsg.style.display = 'none';
}

function updateTrend(currentValue, lastValue, elementId) {
    const element = document.getElementById(elementId);
    if (!lastValue || !currentValue) {
        element.textContent = '';
        return;
    }

    const diff = currentValue - lastValue;
    if (diff > 0) {
        element.innerHTML = `<i class="fas fa-arrow-up"></i> ${diff.toFixed(1)}`;
        element.className = 'data-trend up';
    } else if (diff < 0) {
        element.innerHTML = `<i class="fas fa-arrow-down"></i> ${Math.abs(diff).toFixed(1)}`;
        element.className = 'data-trend down';
    }
}

function formatDate(date) {
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Get month (1-12), pad with 0
    const day = String(date.getDate()).padStart(2, '0'); // Get day (1-31), pad with 0
    const hours = String(date.getHours()).padStart(2, '0'); // Get hours (0-23), pad with 0
    const minutes = String(date.getMinutes()).padStart(2, '0'); // Get minutes (0-59), pad with 0
    const seconds = String(date.getSeconds()).padStart(2, '0'); // Get seconds (0-59), pad with 0

    return `${hours}:${minutes}:${seconds}`;
}

function initChart() {
    // Determine the colors based on BPM values
    const ctx = document.getElementById('bpmAreaChart').getContext('2d');

    const bpmPointColor = bpms.map(bpm => bpm > max_bpm || bpm < min_bpm ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    bpmChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: times,
            datasets: [{
                label: "BPM",
                lineTension: 0.3,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                pointRadius: 3,
                pointBackgroundColor: bpmPointColor,
                pointBorderColor: bpmPointColor,
                pointHoverRadius: 3,
                pointHoverBackgroundColor: 'rgba(0, 0, 0, 1)',
                pointHoverBorderColor: 'rgba(0, 0, 0, 1)',
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: bpms,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 20,
                        callback: function (value, index, values) {
                            return formatDate(value);
                        }
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function (value, index, values) {
                            return value;
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function (tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel;
                    }
                }
            }
        }
    });

    // Determine the colors based on spo2 values
    const spo2Ctx = document.getElementById('spo2AreaChart').getContext('2d');

    const spo2PointColor = spo2s.map(spo2 => spo2 < 85 ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    spo2Chart = new Chart(spo2Ctx, {
        type: 'line',
        data: {
            labels: times,
            datasets: [{
                label: "SPO2",
                lineTension: 0.3,
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderColor: 'rgba(78, 115, 223, 1)',
                pointRadius: 3,
                pointBackgroundColor: spo2PointColor,
                pointBorderColor: spo2PointColor,
                pointHoverRadius: 3,
                pointHoverBackgroundColor: 'rgba(0, 0, 0, 1)',
                pointHoverBorderColor: 'rgba(0, 0, 0, 1)',
                pointHitRadius: 10,
                pointBorderWidth: 2,
                data: spo2s,
            }],
        },
        options: {
            maintainAspectRatio: false,
            layout: {
                padding: {
                    left: 10,
                    right: 25,
                    top: 25,
                    bottom: 0
                }
            },
            scales: {
                xAxes: [{
                    time: {
                        unit: 'date'
                    },
                    gridLines: {
                        display: false,
                        drawBorder: false
                    },
                    ticks: {
                        maxTicksLimit: 20,
                        callback: function (value, index, values) {
                            return formatDate(value);
                        }
                    }
                }],
                yAxes: [{
                    ticks: {
                        maxTicksLimit: 5,
                        padding: 10,
                        // Include a dollar sign in the ticks
                        callback: function (value, index, values) {
                            return value + '%';
                        }
                    },
                    gridLines: {
                        color: "rgb(234, 236, 244)",
                        zeroLineColor: "rgb(234, 236, 244)",
                        drawBorder: false,
                        borderDash: [2],
                        zeroLineBorderDash: [2]
                    }
                }],
            },
            legend: {
                display: false
            },
            tooltips: {
                backgroundColor: "rgb(255,255,255)",
                bodyFontColor: "#858796",
                titleMarginBottom: 10,
                titleFontColor: '#6e707e',
                titleFontSize: 14,
                borderColor: '#dddfeb',
                borderWidth: 1,
                xPadding: 15,
                yPadding: 15,
                displayColors: false,
                intersect: false,
                mode: 'index',
                caretPadding: 10,
                callbacks: {
                    label: function (tooltipItem, chart) {
                        var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                        return datasetLabel + ': ' + tooltipItem.yLabel + '%';
                    }
                }
            }
        }
    });
}

function updateChart() {
    const bpmColor = bpms.map(bpm => bpm > max_bpm || bpm < min_bpm ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    bpmChart.data.datasets[0].data = bpms;
    bpmChart.data.datasets[0].pointBackgroundColor = bpmColor;
    bpmChart.data.datasets[0].pointBorderColor = bpmColor;
    bpmChart.data.labels = times;
    bpmChart.update();

    const spo2Color = spo2s.map(spo2 => spo2 < 85 ? 'rgba(223, 115, 78, 1)' : 'rgba(78, 115, 223, 1)');

    spo2Chart.data.datasets[0].data = spo2s;
    spo2Chart.data.datasets[0].pointBackgroundColor = spo2Color;
    spo2Chart.data.datasets[0].pointBorderColor = spo2Color;
    spo2Chart.data.labels = times;
    spo2Chart.update();
}

function updateUI(data) {

    var current = new Date();
    var time = (current - start_time) / 1000;
    var hours = Math.floor(time / 3600);
    var minutes = Math.floor((time % 3600) / 60);
    var seconds = time % 60;
    var timeString = '';
    if (hours > 0) {
        timeString += hours.toFixed(0) + '時';
    }
    if (minutes > 0) {
        timeString += minutes.toFixed(0) + '分';
    }
    if (seconds > 0) {
        timeString += seconds.toFixed(0) + '秒';
    }
    document.getElementById('exerciseTime').textContent = timeString;

    if (data.time == lastValues.time) {
        return;
    }

    // 更新數值
    document.getElementById('bpm').textContent = data.bpm.toFixed(5) || '--';
    document.getElementById('spo2').textContent = data.spo2.toFixed(5) || '--';
    document.getElementById('accelX').textContent = data.accelX?.toFixed(3) || '--';
    document.getElementById('accelY').textContent = data.accelY?.toFixed(3) || '--';
    document.getElementById('accelZ').textContent = data.accelZ?.toFixed(3) || '--';

    // 更新趨勢
    if (data.bpm) {
        updateTrend(data.bpm, lastValues.bpm, 'bpmTrend');
        lastValues.bpm = data.bpm;

        if (data.bpm != 0 && (data.bpm > max_bpm || data.bpm < min_bpm)) {
            document.getElementById('healthStatus').textContent = "異常";
        }else{
            document.getElementById('healthStatus').textContent = "良好";
        }
    }
    if (data.spo2) {
        updateTrend(data.spo2, lastValues.spo2, 'spo2Trend');
        lastValues.spo2 = data.spo2;

        if (data.spo2 < 85) {
            document.getElementById('healthStatus').textContent = "異常";
        }
    }
    lastValues.time = data.time;

    // 更新監測狀態的視覺效果
    document.body.classList.toggle('is-monitoring', isMonitoring);

    times.push(current);
    bpms.push(data.bpm);
    spo2s.push(data.spo2);
    updateChart();
}

async function startMonitoring() {
    try {
        const response = await fetch('http://172.20.10.14:5000/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log('Start response:', data);

        if (data.status === 'success') {
            document.getElementById('healthStatus').textContent = "--";
            start_time = new Date();
            times = [];
            bpms = [];
            spo2s = [];
            updateChart();

            isMonitoring = true;
            startBtn.disabled = true;
            stopBtn.disabled = false;
            hideError();
            startDataFetch();
        } else {
            showError(data.message);
        }
    } catch (error) {
        showError('啟動失敗: ' + error.message);
    }
}

async function stopMonitoring() {
    try {
        const response = await fetch('http://172.20.10.14:5000/stop', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();
        console.log('Stop response:', data);

        if (data.status === 'success') {
            isMonitoring = false;
            startBtn.disabled = false;
            stopBtn.disabled = true;
            hideError();
        } else {
            showError(data.message);
        }
    } catch (error) {
        showError('停止失敗: ' + error.message);
    }
}

function startDataFetch() {
    const fetchInterval = setInterval(async () => {
        if (!isMonitoring) {
            clearInterval(fetchInterval);
            return;
        }

        try {
            const response = await fetch('http://172.20.10.14:5000/data');
            const data = await response.json();

            if (data.error) {
                showError(data.error);
            } else {
                hideError();
                updateUI(data);
            }
        } catch (error) {
            showError('讀取數據失敗: ' + error.message);
        }
    }, 1000);
}

fetch('http://172.20.10.14:5000//user')
    .then(response => response.json())
    .then(data => {
        console.log(data);
        if (data.success) {
            user_name = data.name;
            user_age = data.age;
            if (user_age < 30) {
                min_bpm = 100;
                max_bpm = 170;
            } else if (user_age < 35) {
                min_bpm = 95;
                max_bpm = 162;
            } else if (user_age < 40) {
                min_bpm = 93;
                max_bpm = 157;
            } else if (user_age < 45) {
                min_bpm = 90;
                max_bpm = 153;
            } else if (user_age < 50) {
                min_bpm = 88;
                max_bpm = 149;
            } else if (user_age < 55) {
                min_bpm = 85;
                max_bpm = 145;
            } else if (user_age < 60) {
                min_bpm = 83;
                max_bpm = 140;
            } else if (user_age < 65) {
                min_bpm = 80;
                max_bpm = 136;
            } else if (user_age < 70) {
                min_bpm = 78;
                max_bpm = 132;
            } else {
                min_bpm = 75;
                max_bpm = 128;
            }

            document.getElementById('userName').textContent = user_name;
        } else {
            window.location.href = './login.html';
        }
    })
    .catch(error => console.error('Error fetching data:', error));

startBtn.addEventListener('click', startMonitoring);
stopBtn.addEventListener('click', stopMonitoring);

initChart();

document.addEventListener('DOMContentLoaded', () => {
    console.log('Page loaded');
});
