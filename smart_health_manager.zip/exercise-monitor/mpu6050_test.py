import smbus
import time
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation

# MPU6050 設置
MPU6050_ADDR = 0x68
PWR_MGMT_1 = 0x6B
ACCEL_XOUT_H = 0x3B

# 初始化 I2C
bus = smbus.SMBus(1)
bus.write_byte_data(MPU6050_ADDR, PWR_MGMT_1, 0)  # 喚醒 MPU6050

# 讀取原始資料的函數
def read_raw_data(addr):
    high = bus.read_byte_data(MPU6050_ADDR, addr)
    low = bus.read_byte_data(MPU6050_ADDR, addr + 1)
    value = ((high << 8) | low)
    if value > 32768:
        value = value - 65536
    return value

# 初始化加速度數據列表
accel_data = {'x': [], 'y': [], 'z': []}

# 初始化 Matplotlib 圖表
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.set_xlim(-2, 2)
ax.set_ylim(-2, 2)
ax.set_zlim(-2, 2)
ax.set_xlabel('X-axis (g)')
ax.set_ylabel('Y-axis (g)')
ax.set_zlabel('Z-axis (g)')

# 更新圖表的函數
def update_graph(num):
    acc_x = read_raw_data(ACCEL_XOUT_H) / 16384.0
    acc_y = read_raw_data(ACCEL_XOUT_H + 2) / 16384.0
    acc_z = read_raw_data(ACCEL_XOUT_H + 4) / 16384.0

    # 每次加入最新數據
    accel_data['x'].append(acc_x)
    accel_data['y'].append(acc_y)
    accel_data['z'].append(acc_z)

    # 保留最近 5 秒的數據 (SAMPLE_RATE = 10)
    if len(accel_data['x']) > 50:
        accel_data['x'].pop(0)
        accel_data['y'].pop(0)
        accel_data['z'].pop(0)

    # 清除圖表並重新繪製最新數據
    ax.cla()
    ax.set_xlim(-2, 2)
    ax.set_ylim(-2, 2)
    ax.set_zlim(-2, 2)
    ax.set_xlabel('X-axis (g)')
    ax.set_ylabel('Y-axis (g)')
    ax.set_zlabel('Z-axis (g)')
    ax.plot(accel_data['x'], accel_data['y'], accel_data['z'], marker='o', color='b')

# 設置動畫更新頻率
ani = FuncAnimation(fig, update_graph, interval=100)

plt.show()
