from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
import time
import smbus

app = Flask(__name__)
CORS(app)

# MPU6050 設定
PWR_MGMT_1 = 0x6B
SMPLRT_DIV = 0x19
CONFIG = 0x1A
GYRO_CONFIG = 0x1B
ACCEL_CONFIG = 0x1C
ACCEL_XOUT_H = 0x3B
ACCEL_YOUT_H = 0x3D
ACCEL_ZOUT_H = 0x3F
GYRO_XOUT_H = 0x43
GYRO_YOUT_H = 0x45
GYRO_ZOUT_H = 0x47

def MPU_Init():
    bus = smbus.SMBus(1)
    device_address = 0x68
    
    # 喚醒 MPU6050
    bus.write_byte_data(device_address, PWR_MGMT_1, 0)
    bus.write_byte_data(device_address, SMPLRT_DIV, 7)
    bus.write_byte_data(device_address, CONFIG, 0)
    bus.write_byte_data(device_address, GYRO_CONFIG, 24)
    bus.write_byte_data(device_address, ACCEL_CONFIG, 0)
    
    return bus, device_address

def read_raw_data(bus, addr, reg):
    high = bus.read_byte_data(addr, reg)
    low = bus.read_byte_data(addr, reg+1)
    value = ((high << 8) | low)
    if value > 32768:
        value = value - 65536
    return value

bus, device_address = MPU_Init()

@app.route('/')
def home():
    return send_from_directory('.', 'index.html')

@app.route('/data')
def get_data():
    # 讀取加速度計數據
    acc_x = read_raw_data(bus, device_address, ACCEL_XOUT_H) / 16384.0
    acc_y = read_raw_data(bus, device_address, ACCEL_YOUT_H) / 16384.0
    acc_z = read_raw_data(bus, device_address, ACCEL_ZOUT_H) / 16384.0
    
    # 讀取陀螺儀數據
    gyro_x = read_raw_data(bus, device_address, GYRO_XOUT_H) / 131.0
    gyro_y = read_raw_data(bus, device_address, GYRO_YOUT_H) / 131.0
    gyro_z = read_raw_data(bus, device_address, GYRO_ZOUT_H) / 131.0
    
    return jsonify({
        'accelerometer': {
            'x': round(acc_x, 2),
            'y': round(acc_y, 2),
            'z': round(acc_z, 2)
        },
        'gyroscope': {
            'x': round(gyro_x, 2),
            'y': round(gyro_y, 2),
            'z': round(gyro_z, 2)
        }
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
