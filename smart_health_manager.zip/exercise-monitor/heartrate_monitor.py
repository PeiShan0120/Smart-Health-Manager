from max30102 import MAX30102
import hrcalc
import threading
import time
import numpy as np
from scipy.signal import savgol_filter
from collections import deque
import matplotlib.pyplot as plt

class HeartRateMonitor(object):
    """
    A class that encapsulates the max30102 device into a thread
    """

    LOOP_TIME = 0.01
    MOVING_AVERAGE_WINDOW = 5  # 移動平均窗口大小
    ALPHA = 0.1  # 低通濾波係數
    INITIAL_DELAY = 10  # 暖機時間延長為 10 秒

    def __init__(self, print_raw=False, print_result=False):
        self.bpm = 0
        self.spo2 = 0
        self.filtered_bpm = 0
        self.filtered_spo2 = 0
        self.bpm_data = deque(maxlen=self.MOVING_AVERAGE_WINDOW)
        self.spo2_data = deque(maxlen=self.MOVING_AVERAGE_WINDOW)
        self.start_time = None  # 用於記錄開始收集數據的時間
        
        # data for plotting
        self.spos = []
        self.bpms = []

        if print_raw:
            print('IR, Red')
        self.print_raw = print_raw
        self.print_result = print_result

    def run_sensor(self):
        sensor = MAX30102()
        ir_data = []
        red_data = []

        self.start_time = time.time()  # 記錄啟動時間

        # run until told to stop
        while not self._thread.stopped:
            # check if any data is available
            num_bytes = sensor.get_data_present()
            if num_bytes > 0:
                # grab all the data and stash it into arrays
                while num_bytes > 0:
                    red, ir = sensor.read_fifo()
                    num_bytes -= 1
                    ir_data.append(ir)
                    red_data.append(red)
                    if self.print_raw:
                        print("{0}, {1}".format(ir, red))

                while len(ir_data) > 100:
                    ir_data.pop(0)
                    red_data.pop(0)

                # 跳過前幾秒的數據
                current_time = time.time()
                elapsed_time = current_time - self.start_time
                if elapsed_time < self.INITIAL_DELAY:
                    continue  # 若仍在暖機時間，跳過處理

                if len(ir_data) == 100:
                    bpm, valid_bpm, spo2, valid_spo2 = hrcalc.calc_hr_and_spo2(ir_data, red_data)
                    
                    # 忽略 SpO2 值小於 70 的數據
                    if valid_spo2 and spo2 >= 70:
                        self.spo2_data.append(spo2)
                        self.spo2 = np.mean(self.spo2_data)
                        
                        # Apply low-pass filter
                        self.filtered_spo2 = (self.ALPHA * self.spo2) + ((1 - self.ALPHA) * self.filtered_spo2)
                        
                        # Store data for plotting
                        self.spos.append(self.filtered_spo2)

                    # 只處理有效的 BPM 數據
                    if valid_bpm:
                        self.bpm_data.append(bpm)
                        self.bpm = np.mean(self.bpm_data)
                        
                        # Apply low-pass filter for more stability
                        self.filtered_bpm = (self.ALPHA * self.bpm) + ((1 - self.ALPHA) * self.filtered_bpm)
                        self.bpms.append(self.filtered_bpm)

                    # Check for finger presence
                    if (np.mean(ir_data) < 50000 and np.mean(red_data) < 50000):
                        self.bpm = 0
                        if self.print_result:
                            print("Finger not detected")

                    if self.print_result and spo2 >= 70:
                        print("Filtered BPM: {0:.2f}, Filtered SpO2: {1:.2f}".format(
                            self.filtered_bpm, self.filtered_spo2))

            time.sleep(self.LOOP_TIME)

        sensor.shutdown()

    def start_sensor(self):
        self._thread = threading.Thread(target=self.run_sensor)
        self._thread.stopped = False
        self._thread.start()

    def stop_sensor(self, timeout=2.0):
        self._thread.stopped = True
        self.bpm = 0
        self._thread.join(timeout)

    def show(self):
        # 丟棄前 INITIAL_DELAY 秒的數據
        sampling_rate = 1 / self.LOOP_TIME  # 假設 LOOP_TIME 是數據點的時間間隔
        discard_points = int(self.INITIAL_DELAY * sampling_rate)

        # 確保 x 軸的長度與 y 軸數據匹配
        length = min(len(self.spos), len(self.bpms)) - discard_points
        if length <= 0:
            print("Not enough data points to display")
            return
            
        x = np.arange(length)
        y_spo2 = np.array(self.spos[discard_points:discard_points + length])
        y_bpm = np.array(self.bpms[discard_points:discard_points + length])

        # 動態調整 window_length，確保不超過數據長度且為奇數
        window_length = min(51, len(y_spo2))
        if window_length % 2 == 0:  # 確保 window_length 為奇數
            window_length -= 1
        
        # 確保 window_length 大於 polyorder (3)
        if window_length <= 3:
            # 如果數據點太少，直接繪製原始數據
            yhat_spo2 = y_spo2
            yhat_bpm = y_bpm
        else:
            # 應用 Savitzky-Golay 濾波
            yhat_spo2 = savgol_filter(y_spo2, window_length, 3)
            yhat_bpm = savgol_filter(y_bpm, window_length, 3)
        
        # Plot with dual Y-axes
        fig, ax1 = plt.subplots(figsize=(10, 6))

        # 左側 Y 軸: SpO2
        ax1.set_xlabel("Time")
        ax1.set_ylabel("SpO2", color="blue")
        ax1.plot(x, yhat_spo2, label="Smoothed SpO2", color="blue")
        ax1.tick_params(axis="y", labelcolor="blue")
        ax1.set_ylim([85, 100])  # 設置 SpO2 的合理範圍

        # 右側 Y 軸: BPM
        ax2 = ax1.twinx()
        ax2.set_ylabel("BPM", color="red")
        ax2.plot(x, yhat_bpm, label="Smoothed BPM", color="red")
        ax2.tick_params(axis="y", labelcolor="red")
        ax2.set_ylim([40, 180])  # 設置 BPM 的合理範圍

        # Add legends and title
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")
        
        fig.suptitle("Smoothed SpO2 and BPM over Time")
        fig.tight_layout()  # 自動調整圖表佈局
        plt.show()
